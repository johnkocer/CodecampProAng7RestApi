module.exports = function () {
  var data={
       employee : [
        { id: 1, name: 'Ms. Nice', gender:'Male', salary:10000, departmentId:1 },
        { id: 2, name: 'Mr. Nice', gender:'Female', salary:5000, departmentId:1 },
        { id: 3, name: 'Narco' , gender:'Male', salary:8000, departmentId:1 },
        { id: 4, name: 'Bombasto' , gender:'Male', salary:9000, departmentId:1 },
        { id: 5, name: 'Celeritas' , gender:'Male', salary:10000, departmentId:1 }
      ]
    }
    return data
  }
