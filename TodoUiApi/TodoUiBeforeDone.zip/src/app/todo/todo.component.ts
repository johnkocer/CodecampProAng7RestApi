import { Component, OnInit } from "@angular/core";
import { Todo } from "../todo";
import { TODOS } from "../mock-todos";
import { TodoService } from "../todo.service";

@Component({
  selector: "app-todo",
  templateUrl: "./todo.component.html",
  styleUrls: ["./todo.component.css"]
})
export class TodoComponent implements OnInit {
  // todos = TODOS;
  selectedTodo: Todo;

  public todos: Todo[];
  showEditor = true;
  myName: string;
  newTodo: Todo;
  findTodo: Todo;

  constructor(private dataService: TodoService) {
    this.newTodo = new Todo();
    this.findTodo = new Todo();
    this.findTodo.name = "";}

  ngOnInit() {
    this.search();
  }
  onSelect(todo: Todo): void {
    this.selectedTodo = todo;
  }

  // add(name: string): void {
  //   name = name.trim();
  //   if (!name) {
  //     return;
  //   }
  //   this.todos.push({ id: this.todos.length + 1, name: name });
  // }
 search() {
    this.dataService.search().subscribe(
      (data: Todo[]) => {
        this.todos = data;
      },
      error => {
        console.log("could not get Todos", error);
        this.todos = null;
      }
    );
  }

  public add(item: Todo) {
    this.dataService.post(this.newTodo).subscribe(
      (data: Todo) => {
        this.todos.push(data);
      },
      error => {
        console.log("oops could not add Todo", error);
      }
    );
  }

  public update(item: Todo) {
    this.dataService.put(item).subscribe(
      todo => {
        this.search();
      },
      error => {
        console.log("oops could not update Todo", error);
      }
    );
  }

  public delete(todo: Todo) {
    this.dataService.delete(todo.id).subscribe(
      data => {
        console.log("Todo deleted");
        this.search();
      },
      error => {
        console.log("oops could not delete Todo", error);
      }
    );
  }

  get() {
    this.dataService.get(this.findTodo.id).subscribe(
      e => {
        if (e == null) {
          let todoFind = new Todo();
          todoFind.id = this.findTodo.id;
          this.findTodo = todoFind;
        } else if (e != undefined) {
          this.findTodo = e;
        }
      },
      error => {
        this.findTodo = new Todo();
        console.log("could not get Todo", error);
      }
    );
  }
}
